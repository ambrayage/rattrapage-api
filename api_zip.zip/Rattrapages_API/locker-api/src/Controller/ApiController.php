<?php

namespace App\Controller;

use App\Entity\Item;
use App\Repository\ItemRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Serializer\Normalizer\AbstractNormalizer;

class ApiController extends AbstractController
{
    #[Route('/api/items', name: 'api_items_list', methods: ['GET'])]
    public function list(ItemRepository $repo): JsonResponse
    {
        return $this->json($repo->findAll(), 200, [], ['groups' => 'item:read']);
    }

    #[Route('/api/items', name: 'api_items_add', methods: ['POST'])]
    public function add(Request $request, EntityManagerInterface $em, SerializerInterface $serializer): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        if (!isset($data['login'], $data['password'], $data['url'])) {
            return $this->json(['error' => 'Champs manquants'], 400);
        }

        $item = new Item();
        $item->setLogin($data['login']);
        $item->setPassword($data['password']);
        $item->setUrl($data['url']);

        $em->persist($item);
        $em->flush();

        return $this->json($item, 201, [], ['groups' => 'item:read']);
    }

    #[Route('/api/items/{id}', name: 'api_items_delete', methods: ['DELETE'])]
    public function delete(Item $item, EntityManagerInterface $em): JsonResponse
    {
        $em->remove($item);
        $em->flush();

        return $this->json(null, 204);
    }
}
