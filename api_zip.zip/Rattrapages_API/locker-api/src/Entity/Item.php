<?php

namespace App\Entity;

use App\Repository\ItemRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ItemRepository::class)
 */
use Symfony\Component\Serializer\Annotation\Groups;

#[ORM\Entity]
class Item
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['item:read'])]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    #[Groups(['item:read'])]
    private ?string $login = null;

    #[ORM\Column(length: 255)]
    #[Groups(['item:read'])]
    private ?string $password = null;

    #[ORM\Column(length: 255)]
    #[Groups(['item:read'])]
    private ?string $url = null;

    // Getters / Setters ici
    public function getId(): ?int
    {
        return $this->id;
    }
    public function getLogin(): ?string
    {
        return $this->login;
    }
    public function getPassword(): ?string
    {
        return $this->password;
    }
    public function getUrl(): ?string
    {
        return $this->url;
    }
    public function setLogin(string $login): self
    {
        $this->login = $login;
        return $this;
    }
    public function setPassword(string $password): self
    {
        $this->password = $password;
        return $this;
    }
    public function setUrl(string $url): self
    {
        $this->url = $url;
        return $this;
    }
}